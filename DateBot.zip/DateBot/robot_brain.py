"""
File: robot_brain.py
Author: Jaden Mounteer
Purpose: This class represents the robot's brain. It is used to make the robot think and make decisions.
"""

class Robot_Brain():
    """
    This class represents the robot's brain. It is used to make the robot think and make decisions.
    """
    def __init__(self):
        """
        Initiates the robot brain's member variables so that 
        the brain can store information given by the user.
        :return: None
        """
        self.season = ""
        self.month = ""
        self.time = ""
        self.budget = ""

    def advance(self):
        """
        Causes the brain to work.
        :return: None
        """
        pass

    def ask_question(self):
        """
        Causes the robot to ask a question for the user
        to answer.
        :return: None
        """
        pass

    def comment(self):
        """
        Causes the robot to comment on something the
        user said.
        :return: None
        """
        pass

    def make_decision(self):
        """
        Causes the robot to make a decision based on the give
        information.
        :return: decision
        """
        pass